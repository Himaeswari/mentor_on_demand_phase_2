package com.mentor.mentorOnDemand.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mentor.mentorOnDemand.dao.LoginDao;
import com.mentor.mentorOnDemand.model.Login;
import com.mentor.mentorOnDemand.model.Mentor;
import com.mentor.mentorOnDemand.service.AdminService;
import com.mentor.mentorOnDemand.service.MentorService;
import com.mentor.mentorOnDemand.service.UserService;

@Controller
public class LoginController {
	
	@Autowired
	private LoginDao loginDao;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private MentorService mentorService;
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping(value = "/Login", method = RequestMethod.GET)
    public ModelAndView home(ModelMap model,HttpServletRequest request)
	{
		 
		 if(null!=(request.getAttribute("message")))
		 {
		 String message1=(String) request.getAttribute("message");
		 System.out.println("message "+message1);
		 request.setAttribute("message",message1);
		 }
		Mentor mentor= new Mentor();
		model.addAttribute("mentor",mentor);
		Login login = new Login();
		model.addAttribute("login",login);
		
		return new ModelAndView("login");
	}
	
	@RequestMapping(value="/getRole/login" ,method = RequestMethod.POST)
	public String getLoginDetails(@ModelAttribute("login") Login login,@ModelAttribute("mentor") Mentor mentor,HttpServletRequest request) {
		
	    System.out.println("hiii");
		String  email=login.getEmail();
		System.out.println(email);
		String  password=login.getPassword();
		Login logins = loginDao.findByRole(email,password);
		if(logins==null)
		{
			
			request.setAttribute("message","Invalid UserId or Password" );
			System.out.println(request.getAttribute("message"));
			return "redirect:/Login";
		}
		System.out.println(logins.getRole());
		if(logins.getRole().equals("admin"))
		{
			String emails= logins.getEmail();
			long userId = adminService.getAdminId(emails);
			HttpSession session = request.getSession(); 
			session.setAttribute("userId",userId);
			return "adminLandingPage";
		}
		else if(logins.getRole().equals("user"))
		{
			String emails= logins.getEmail();
			long userId = userService.getUserId(emails);
			
			HttpSession session = request.getSession(); 
			session.setAttribute("userId",userId);
			return "redirect:/userLanding";
		}
		else
		{
			String emails= logins.getEmail();
			long userId = mentorService.getMentorId(emails);
			HttpSession session = request.getSession(); 
			session.setAttribute("userId",userId);
			return "redirect:/proposalList";
		}
		
		
		
	}

}
