package com.mentor.mentorOnDemand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentor.mentorOnDemand.dao.ProposalRequestDao;
import com.mentor.mentorOnDemand.model.ProposalRequest;


@Service
public class ProposalRequestService {

	@Autowired
	private ProposalRequestDao proposalRequestDao;
	
	public void proposeMentor(ProposalRequest proposalRequest) {
		
		proposalRequestDao.save(proposalRequest);
		
		
		
	}

	public List<ProposalRequest> findByMentorId(long userId) {
		System.out.println(proposalRequestDao.findByMentorId(userId));
				return proposalRequestDao.findByMentorId(userId);
	}

}
