package com.mentor.mentorOnDemand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentor.mentorOnDemand.dao.MentorDao;
import com.mentor.mentorOnDemand.model.Mentor;

@Service
public class MentorService {
	
	@Autowired
	private MentorDao mentorDao;

	public void insertMentor(Mentor mentor) {
		mentorDao.save(mentor);
		
	}

	public List<Mentor> getMentors(String time, String skill) {
		
		System.out.println(time);
		System.out.println(skill);
	List<Mentor> mentors =mentorDao.getMentors(time,skill);
	System.out.println(mentors);
	return mentors;
	}

	public int getMentorId(String emails) {
		// TODO Auto-generated method stub
		return mentorDao.getMentorId(emails);
	}

	public String getMentorSkill(long mentorId) {
		
		return mentorDao.getMentorSkill(mentorId);
	}

}
