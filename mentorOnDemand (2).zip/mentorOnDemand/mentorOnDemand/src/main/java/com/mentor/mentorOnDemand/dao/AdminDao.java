package com.mentor.mentorOnDemand.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mentor.mentorOnDemand.model.Admin;

@Repository
public interface AdminDao extends JpaRepository<Admin,Long>{

	 @Query("Select e.adminId from Admin e where e.email= :emails")
		public int getAdminId(@Param("emails") String emails);

}
