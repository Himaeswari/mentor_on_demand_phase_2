package com.mentor.mentorOnDemand.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mentor.mentorOnDemand.model.Mentor;


@Repository
public interface MentorDao extends JpaRepository<Mentor,Long>{

	@Query("Select m from Mentor m where m.regDateTime= :time and m.skills= :skill")
	public List<Mentor> getMentors(@Param("time") String time,@Param("skill") String skill);

	 @Query("Select e.mentorId from Mentor e where e.email= :emails")
	public int getMentorId(@Param("emails") String emails);

	 
	 @Query("Select e.skills from Mentor e where e.mentorId= :mentorId")
	public String getMentorSkill(@Param("mentorId") long mentorId);

}
