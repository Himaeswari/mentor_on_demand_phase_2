package com.mentor.mentorOnDemand.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mentor.mentorOnDemand.dao.UserDao;
import com.mentor.mentorOnDemand.model.Mentor;
import com.mentor.mentorOnDemand.model.User;

@Service
public class UserService {
	
	@Autowired
	private UserDao userDao;

	public void insertUser(User user) {
	     userDao.save(user);
		
	}

	public int getUserId(String emails) {
		
		return userDao.getUserId(emails);
	}
	
	

}
