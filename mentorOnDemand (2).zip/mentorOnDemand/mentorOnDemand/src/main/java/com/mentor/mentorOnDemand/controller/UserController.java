package com.mentor.mentorOnDemand.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mentor.mentorOnDemand.dao.LoginDao;
import com.mentor.mentorOnDemand.dao.UserPaymentDao;
import com.mentor.mentorOnDemand.model.Login;
import com.mentor.mentorOnDemand.model.Mentor;
import com.mentor.mentorOnDemand.model.ProposalRequest;
import com.mentor.mentorOnDemand.model.Skills;
import com.mentor.mentorOnDemand.model.User;
import com.mentor.mentorOnDemand.model.UserPayment;
import com.mentor.mentorOnDemand.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private LoginDao loginDao;
	
	@Autowired
	private UserPaymentDao userPaymentDao;

	@RequestMapping(value = "/registerUser", method = RequestMethod.GET)
	public String adminsRegistration(ModelMap model) {
		Mentor mentor = new Mentor();
		model.addAttribute("mentor", mentor);
		User user = new User();
		System.out.print("******************************");

		model.addAttribute("user", user);
		return "userRegistration";
	}

	@RequestMapping(value = "/usersRegistration", method = RequestMethod.POST)
	public String formHandler(@ModelAttribute("user") User user, BindingResult result, Model model) {

		if (result.hasErrors()) {
			System.out.println("error");
			model.addAttribute("user", user);
			return "userRegistration";
		}
		try {
			Login loginDetails = loginDao.save(new Login(user));
			System.out.println(user.getEmail());
			userService.insertUser(user);
			Mentor mentor = new Mentor();
			model.addAttribute("mentor", mentor);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "adminLogin";

	}

	@RequestMapping(path = "/userLanding")
	public String userLanding(ModelMap model) {
		Mentor mentor = new Mentor();
		model.addAttribute("mentor", mentor);
		return "userLandingPage";
	}

	
	@RequestMapping(path="/confirmedProposals")
	public String confirmedProposals(HttpServletRequest request)
	{
		List<UserPayment> userPayment = new ArrayList<UserPayment>();
		HttpSession session =request.getSession(false);
      	long userId = (long)session.getAttribute("userId");
      	System.out.println("userId "+userId);
	    userPayment = userPaymentDao.findByUserId(userId);
		System.out.println("hello  "+userPayment);
		if(userPayment!=null)
		{
		request.setAttribute("userPayment",userPayment);
		return "confirmProposals";
		}
		else
		{
			return "noConfirmations";
		}
		
		
	}
	
	@RequestMapping(path="/makePayment")
	public String approveProposals(@RequestParam("pId") long id, HttpServletRequest request)
	{
		Skills skills = new Skills();
		
		UserPayment userPayment = userPaymentDao.findByPaymentId(id);
		
		userPayment.setPaymentId(id);
		userPayment.setStatus("Paid");
		userPaymentDao.save(userPayment);
		/*
		 * List<ProposalRequest> pr = new ArrayList<ProposalRequest>(); HttpSession
		 * session =request.getSession(false); long mentorId =
		 * (long)session.getAttribute("userId"); String skill=
		 * mentorService.getMentorSkill(mentorId); skills
		 * =skillDao.findBySkillName(skill); System.out.println(skills.getSkillId());
		 * System.out.println(skills.getBaseAmount());
		 * userPayment.setMentorId(mentorId); userPayment.setUserId(id);
		 * userPayment.setPaymentAmount(skills.getBaseAmount());
		 * userPayment.setSkillId(skills.getSkillId());
		 * userPayment.setStatus("Not Payed"); userPaymentDao.save(userPayment);
		 */
		return "proposeRequest";
	}
	/*
	 * @RequestMapping(value="/userLogin", method = RequestMethod.POST) public
	 * String userLogin(@ModelAttribute("login") Login login,HttpServletRequest
	 * request) {
	 * 
	 * 
	 * HttpSession session = request.getSession(); session.setAttribute(name,
	 * value);
	 * 
	 * return null;
	 * 
	 * }
	 */
	
	

}
