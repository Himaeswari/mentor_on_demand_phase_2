package com.mentor.mentorOnDemand.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mentor.mentorOnDemand.model.Login;

@Repository
public interface LoginDao extends JpaRepository<Login,Long>{

	@Query(value = "SELECT login FROM Login login WHERE login.email=?1 AND login.password=?2")
	Login findByRole(String email, String password);


}
